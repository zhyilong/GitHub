//
//  ViewController.m
//  UNSlideController
//
//  Created by zhangyilong on 16/1/13.
//  Copyright © 2016年 zhangyilong. All rights reserved.
//

#import "ViewController.h"
#import "UNSlideController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    UIViewController* menuctrl = [[UIViewController alloc] init];
    menuctrl.view.backgroundColor = [UIColor blueColor];
    
    UIView* view = [[UIView alloc] initWithFrame:CGRectMake(0, 30, 150, 150)];
    view.backgroundColor = [UIColor grayColor];
    [menuctrl.view addSubview:view];
    
    UIViewController* homectrl = [[UIViewController alloc] init];
    homectrl.view.backgroundColor = [UIColor brownColor];
    
//    UITableView* table = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 400) style:UITableViewStylePlain];
//    [homectrl.view addSubview:table];
    
    UIView* table = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 400)];
    table.backgroundColor = [UIColor greenColor];
    [homectrl.view addSubview:table];
    
    UIScrollView* scroll = [[UIScrollView alloc] initWithFrame:table.bounds];
    scroll.backgroundColor = [UIColor orangeColor];
    scroll.contentSize = CGSizeMake(300, 1000);
    [table addSubview:scroll];
    
    UNSlideController* slidecontroller = [[UNSlideController alloc] initWithController:homectrl MenuController:menuctrl];
    [self presentViewController:slidecontroller animated:YES completion:^{
        //
    }];
}

@end
